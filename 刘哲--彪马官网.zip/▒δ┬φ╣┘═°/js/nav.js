var ul1_lis = document.querySelector('.ul1').children;
var ul2List = document.querySelector('.ul1').querySelectorAll('.ul2');
var ul2_imgs = document.querySelectorAll('.ul2-img');

for (let i = 0; i < ul1_lis.length; i++) {
    ul1_lis[i].index = i;
    ul1_lis[i].onmouseover = function () {
        for (let j = 0; j < ul1_lis.length; j++) {
            ul1_lis[j].style.backgroundColor = ''
            ul2List[j].style.zIndex = '1'
            ul2_imgs[j].style.display = 'none'
        }
        this.style.backgroundColor = '#fff'
        ul2List[this.index].style.zIndex = '2'
        ul2_imgs[this.index].style.display = 'block'
    }
}
