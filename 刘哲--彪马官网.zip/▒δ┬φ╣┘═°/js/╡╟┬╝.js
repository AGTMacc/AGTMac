var iptas = document.querySelector('.login-input')
var ipt = document.querySelector('.login-input').querySelector('input')

ipt.onfocus = iptfocuss
function iptfocuss() {
    ipt.style.borderColor = '#333'
    iptas.querySelector('label').style.top = '5px';
    iptas.querySelector('label').style.fontSize = '12px';
    ipt.style.padding = "20px 10px 0"
}

function iptblurs(str1, str2, str3) {
    if (ipt.value == '') {
        iptas.querySelector('span').innerText = str1;
        iptas.querySelector('span').style.color = 'red';
        ipt.style.borderColor = 'red'
        iptas.querySelector('label').style.top = '';
        iptas.querySelector('label').style.fontSize = '';
        ipt.style.padding = ""
    } else {
        var reg = /^1[0-9]{10}$/
        if (reg.test(ipt.value)) {
            iptas.querySelector('span').innerText = str2;
            iptas.querySelector('span').style.color = 'green';
            ipt.style.borderColor = ''
        } else {
            iptas.querySelector('span').innerText = str3;
            iptas.querySelector('span').style.color = 'red';
            ipt.style.borderColor = 'red'
        }
    }
}
ipt.onblur = function () {
    var str1 = '输入框不能为空'
    var str2 = '手机号输入正确'
    var str3 = '请输入有效的手机号'
    iptblurs(str1, str2, str3);
}

var iptpas = document.querySelector('.login-password')
var iptpass = document.querySelector('.login-password').querySelector('input');
iptpass.onfocus = passfocuss
function passfocuss() {
    iptpass.style.borderColor = '#333'
    iptpas.querySelector('label').style.top = '5px';
    iptpas.querySelector('label').style.fontSize = '12px';
    iptpass.style.padding = "20px 10px 0"
}

function passblurs(str1, str2, str3) {
    if (iptpass.value == '') {
        iptpas.querySelector('span').innerText = str1;
        iptpas.querySelector('span').style.color = 'red';
        iptpass.style.borderColor = 'red'
        iptpas.querySelector('label').style.top = '';
        iptpas.querySelector('label').style.fontSize = '';
        iptpass.style.padding = ""
    } else {
        var reg = /^[0-9a-zA-Z]{6,16}$/
        if (reg.test(iptpass.value)) {
            iptpas.querySelector('span').innerText = str2;
            iptpas.querySelector('span').style.color = 'green';
            iptpass.style.borderColor = ''
        } else {
            iptpas.querySelector('span').innerText = str3;
            iptpas.querySelector('span').style.color = 'red';
            iptpass.style.borderColor = 'red'
        }
    }
}
iptpass.onblur = function () {
    var str1 = '输入框不能为空'
    var str2 = '密码输入正确'
    var str3 = '密码为6-16位数字字母组合'
    passblurs(str1, str2, str3);
}