var search = document.getElementById('search');
var search_ipt = document.getElementById('search-ipt');
var link = document.getElementById('link');

search.onclick = function () {
    link.style.display = 'none'
    search_ipt.style.width = '300px'
    search.style.display = 'none'
    search_ipt.querySelector('input').focus();
}

search_ipt.querySelector('input').onblur = function () {
    link.style.display = ''
    search_ipt.style.width = ''
    search.style.display = ''
}