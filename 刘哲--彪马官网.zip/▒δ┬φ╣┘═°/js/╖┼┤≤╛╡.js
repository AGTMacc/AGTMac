var prList = document.querySelector('.product-1-lt').querySelectorAll('li');
var datu = document.querySelector('.datu');

var t = 1;
prList[0].style.borderColor = 'red'
for (let i = 0; i < prList.length; i++) {
    prList[i].onclick = function () {
        datu.querySelector('img').src = this.querySelector('img').src;
        for (let j = 0; j < prList.length; j++) {
            prList[j].style.borderColor = '#999'
            this.style.borderColor = 'red'
        }
    }
}
function bodyScroll(event) {
    event.preventDefault();
}
function scrControl(t) {
    if (t == 0) {
        document.body.addEventListener('scroll', this.bodyScroll, { passive: false });
    } else if (t == 1) {
        document.body.removeEventListener('scroll', this.bodyScroll, { passive: false });
    }
}
datu.onmouseover = function (e) {
    t = 0
    var imgwidth = 1000;
    datu.querySelector('img').style.width = imgwidth + 'px'
    datu.style.cursor = 'crosshair';

    document.onmousemove = function (e) {
        var x = e.pageX - datu.parentNode.offsetLeft - datu.offsetLeft;
        var y = e.pageY - datu.parentNode.offsetTop - datu.offsetTop;

        var x1 = x / datu.clientWidth * (datu.querySelector('img').clientWidth - datu.clientWidth);
        var y1 = y / datu.clientHeight * (datu.querySelector('img').clientHeight - datu.clientHeight);

        datu.querySelector('img').style.top = -y1 + 'px'
        datu.querySelector('img').style.left = -x1 + 'px'
    }
    datu.onmousewheel = function (e) {
        if (e.wheelDelta < 0) {
            imgwidth -= 10
        } else {
            imgwidth += 10
        }
        if (imgwidth >= 1000) {
            imgwidth = 1000
        } else if (imgwidth <= 500) {
            imgwidth = 500
        }
    }
}
datu.onmouseout = function () {
    t = 1
    datu.querySelector('img').style.width = ''
    datu.style.cursor = ''
    document.onmousemove = null;
    datu.querySelector('img').style.top = ''
    datu.querySelector('img').style.left = ''
}