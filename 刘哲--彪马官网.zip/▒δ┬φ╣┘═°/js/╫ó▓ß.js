var ipt_tel = document.querySelector('#ipt-tel');
var telipt = ipt_tel.querySelector('input');
var regi_yzm = document.querySelector('.regi-yzm');

telipt.onfocus = telfocuss
function telfocuss() {
    telipt.style.borderColor = '#333'
    ipt_tel.querySelector('label').style.top = '5px';
    ipt_tel.querySelector('label').style.fontSize = '12px';
    telipt.style.padding = "20px 10px 0"
}

function telblurs(str1, str2, str3) {
    if (telipt.value == '') {
        ipt_tel.querySelector('span').innerText = str1;
        ipt_tel.querySelector('span').style.color = 'red';
        telipt.style.borderColor = 'red'
        ipt_tel.querySelector('label').style.top = '';
        ipt_tel.querySelector('label').style.fontSize = '';
        telipt.style.padding = ""
    } else {
        var reg = /^1[0-9]{10}$/
        if (reg.test(telipt.value)) {
            ipt_tel.querySelector('span').innerText = str2;
            ipt_tel.querySelector('span').style.color = 'green';
            telipt.style.borderColor = ''
            regi_yzm.style.display = 'block'
        } else {
            ipt_tel.querySelector('span').innerText = str3;
            ipt_tel.querySelector('span').style.color = 'red';
            telipt.style.borderColor = 'red'
            regi_yzm.style.display = 'none'
        }
    }
}
telipt.onblur = function () {
    var str1 = '输入框不能为空'
    var str2 = '手机号输入正确'
    var str3 = '请输入有效的手机号'
    telblurs(str1, str2, str3);
}

var fason = document.getElementById('fason');

fason.onclick = function () {
    fason.disabled = true;
    fason.style.cursor = 'default'
    fason.style.backgroundColor = '#999';
    var num = 30
    var time1 = setInterval(function () {
        num--
        fason.value = num + '秒后可点击'
        if (num == 0) {
            fason.disabled = false;
            num = 30
            fason.style.cursor = 'pointer'
            clearInterval(time1);
            fason.value = '发送验证码'
            fason.style.backgroundColor = '';
        }
    }, 1000);
}

var rp1 = document.getElementById('rp1');

rp1.querySelector('input').onfocus = function () {
    this.style.borderColor = '#333'
    rp1.querySelector('label').style.top = '5px';
    rp1.querySelector('label').style.fontSize = '12px';
    this.style.padding = "20px 10px 0"
}

rp1.querySelector('input').onblur = function () {
    var str1 = '输入框不能为空'
    var str2 = '密码输入正确'
    var str3 = '密码为6-16位数字字母组合'
    rp11(str1, str2, str3);
};
function rp11(str1, str2, str3) {
    if (rp1.querySelector('input').value == '') {
        rp1.querySelector('span').innerText = str1;
        rp1.querySelector('span').style.color = 'red';
        rp1.querySelector('input').style.borderColor = 'red'
        rp1.querySelector('label').style.top = '';
        rp1.querySelector('label').style.fontSize = '';
        rp1.querySelector('input').style.padding = ""
    } else {
        var reg = /^[0-9a-zA-Z]{6,16}$/
        if (reg.test(rp1.querySelector('input').value)) {
            rp1.querySelector('span').innerText = str2;
            rp1.querySelector('span').style.color = 'green';
            rp1.querySelector('input').style.borderColor = ''
            regi_yzm.style.display = 'block'
        } else {
            rp1.querySelector('span').innerText = str3;
            rp1.querySelector('span').style.color = 'red';
            rp1.querySelector('input').style.borderColor = 'red'
            regi_yzm.style.display = 'none'
        }
    }
}

var rp2 = document.getElementById('rp2');

rp2.querySelector('input').onfocus = function () {
    this.style.borderColor = '#333'
    rp2.querySelector('label').style.top = '5px';
    rp2.querySelector('label').style.fontSize = '12px';
    this.style.padding = "20px 10px 0"
}

rp2.querySelector('input').onblur = function () {
    var str1 = '输入框不能为空'
    var str2 = '密码输入正确'
    var str3 = '两次密码输入不一致'
    rp21(str1, str2, str3);
};
function rp21(str1, str2, str3) {
    if (rp2.querySelector('input').value == '') {
        rp2.querySelector('span').innerText = str1;
        rp2.querySelector('span').style.color = 'red';
        rp2.querySelector('input').style.borderColor = 'red'
        rp2.querySelector('label').style.top = '';
        rp2.querySelector('label').style.fontSize = '';
        rp2.querySelector('input').style.padding = ""
    } else {
        if (rp1.querySelector('input').value == rp2.querySelector('input').value) {
            rp2.querySelector('span').innerText = str2;
            rp2.querySelector('span').style.color = 'green';
            rp2.querySelector('input').style.borderColor = ''
            regi_yzm.style.display = 'block'
        } else {
            rp2.querySelector('span').innerText = str3;
            rp2.querySelector('span').style.color = 'red';
            rp2.querySelector('input').style.borderColor = 'red'
            regi_yzm.style.display = 'none'
        }
    }
}

var bixuan = document.getElementById('bixuan');
var buxuanbtn = document.getElementById('buxuanbtn');

bixuan.onchange = function () {
    buxuanbtn.disabled = !buxuanbtn.disabled;
    if (buxuanbtn.disabled == false) {
        buxuanbtn.style.backgroundColor = '#000';
        buxuanbtn.style.cursor = 'pointer';
    } else {
        buxuanbtn.style.backgroundColor = '';
        buxuanbtn.style.cursor = '';
    }


}