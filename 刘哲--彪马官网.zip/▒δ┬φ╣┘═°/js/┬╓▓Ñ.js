var btn_lt = document.getElementById('btn-lt');
var btn_rt = document.getElementById('btn-rt');
var bottom = document.getElementById('bottom-1');
var ul = document.getElementById('bottom-1').querySelector('ul');
var lis = ul.children;

var count = 0
btn_rt.onclick = function () {
    count++;
    getclick(lis.length - 1, 0);
}

btn_lt.onclick = function () {
    count--;
    getclick(0, lis.length - 1);
}

function getclick(num1, num2) {
    if (count == num1) {
        ul.style.left = count * -700 + 'px';
        count = num2
        setTimeout(function () {
            ul.style.transition = '0s'
            ul.style.left = count * -700 + 'px';
        }, 800)
    } else {
        ul.style.transition = '.8s'
        ul.style.left = count * -700 + 'px';
    }
}

var time = setInterval(function () {
    btn_rt.onclick();
}, 3000)

bottom.onmouseover = function () {
    clearInterval(time)
}
bottom.onmouseout = function () {
    time = setInterval(function () {
        btn_rt.onclick();
    }, 3000)
}