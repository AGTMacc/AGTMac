var fh = document.querySelector('.fh');
var header_top = document.querySelector('.header-top');

window.onmousewheel = function (e) {
    if (document.documentElement.scrollTop >= 350 && e.wheelDelta < 0) {
        header_top.style.display = 'none';
    } else {
        header_top.style.display = 'block';
    }
    if (document.documentElement.scrollTop >= 250) {
        fh.style.display = 'block';
    } else {
        fh.style.display = 'none';
    }
}

fh.onclick = function () {
    document.documentElement.scrollTop = 0
}