var mian5_lt = document.querySelector('.mian5-lt');
var mian5_rt = document.querySelector('.mian5-rt');
var mian5_ul = document.querySelector('#mian5-ul');

var count1 = 0
mian5_lt.onclick = function () {
    count1++
    if (count1 >= 6) {
        count1 = 6
    }
    mian5_ul.style.left = count1 * -325 + 'px'
}
mian5_rt.onclick = function () {
    count1--
    if (count1 <= 0) {
        count1 = 0
    }
    mian5_ul.style.left = count1 * -325 + 'px'
}

mian5_ul.onmousedown = function (e) {
    var x = e.pageX - mian5_ul.offsetLeft - mian5_ul.parentNode.offsetLeft;
    var x2;
    document.onmousemove = function (e) {
        var x3 = x
        var x1 = e.pageX - x;
        x2 = count1 * -325 + x1
        if (x2 >= 0) {
            x2 = 0
        } else if (x2 <= -1950) {
            x2 = -1950
        } else {
            x2 = x2
        }
        console.log(mian5_ul.parentNode.offsetLeft);
        mian5_ul.style.left = x2 + 'px'
    }
    mian5_ul.onmouseup = function () {
        var count12 = Math.round(x2 / 325);
        count1 = -count12
        if (count1 >= 6) {
            count1 = 6
        } else if (count1 <= 0) {
            count1 = 0
        }

        mian5_ul.style.left = count1 * -325 + 'px'
        document.onmousemove = null
    }

}

mian5_ul.addEventListener('contextmenu', function (e) {
    e.preventDefault();  // 阻止默认事件
});
mian5_ul.addEventListener('selectstart', function (e) {
    e.preventDefault();
});